MongoDB server URI: mongodb+srv://test_user:test@cluster0testfullstackdo.mxhexez.mongodb.net/Exams23001

Render deployment URL: https://quiz2serverfullstackdouglas.onrender.com/

Github URL: https://github.com/francovegao/quiz2ServerFullStackDouglas

Part 1 is localhost app

Part 2 is deployment code

